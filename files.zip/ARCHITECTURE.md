# Arquitetura de Permissões — Controle de Mochila TI

## Estrutura de Pastas

```
core/
├── permissions.py              ← Única fonte de verdade sobre acesso
├── mixins.py                   ← Mixins de view usando permissions.py
├── models.py                   ← Meta.permissions com perms customizadas
├── views.py                    ← Orquestração pura (sem lógica de negócio)
├── forms.py                    ← Sem alteração
├── urls.py                     ← Sem alteração
├── tests.py                    ← Testes da camada de permissões e serviços
├── services/
│   ├── __init__.py
│   └── viagem_service.py       ← Regras de negócio de Viagem
├── management/
│   └── commands/
│       └── setup_groups.py     ← Cria grupos e atribui permissões
└── migrations/
    └── 0007_viagem_custom_permissions.py
```

---

## Fluxo de Permissões

```
Request HTTP
    │
    ▼
View (mixin)
    │ chama
    ▼
permissions.py          ← has_perm() / filtrar_viagens()
    │ aprovado
    ▼
services/viagem_service.py   ← valida negócio + executa
    │ resultado
    ▼
View → Response HTTP
```

---

## Grupos e Permissões

| Grupo       | Permissões chave                                    |
|-------------|-----------------------------------------------------|
| Admin       | is_superuser=True → acesso total                   |
| Supervisor  | `supervisor_access`, `finalizar_viagem`, CRUD total |
| Usuário     | view_* em todas as entidades (somente leitura)      |

### Permissões customizadas (em `Viagem.Meta.permissions`)

| codename           | descrição                        |
|--------------------|----------------------------------|
| `supervisor_access`| Pode criar/editar/excluir        |
| `admin_access`     | Acesso administrativo completo   |
| `finalizar_viagem` | Pode finalizar uma viagem        |

---

## Como usar `has_perm()`

```python
# No código Python:
user.has_perm("core.supervisor_access")   # True para Supervisor e Admin
user.has_perm("core.finalizar_viagem")    # True para Supervisor e Admin
user.has_perm("core.view_viagem")         # True para todos os grupos

# Via permissions.py (preferido):
from core import permissions as perms
perms.pode_ver_viagem(user, viagem)       # inclui lógica multi-tenant
perms.pode_finalizar_viagem(user)
perms.filtrar_viagens(user, queryset)     # filtra por usuário se necessário
```

---

## Setup Inicial (após migrate)

```bash
# 1. Aplicar migrations
python manage.py migrate

# 2. Criar grupos e permissões
python manage.py setup_groups

# 3. Criar superusuário
python manage.py createsuperuser
```

### Atribuir grupo a um usuário existente via shell

```python
from django.contrib.auth.models import User, Group

user = User.objects.get(username="joao")
grupo = Group.objects.get(name="Supervisor")
user.groups.clear()
user.groups.add(grupo)
```

### Via Admin Django

`/admin/` → **Auth → Users** → selecione o usuário → aba **Groups** → adicione o grupo.

---

## Multi-Tenant (expansão futura)

Para filtrar por loja, altere apenas `permissions.py`:

```python
# permissions.py
def filtrar_viagens(user, qs, loja=None):
    if _pode_editar(user):
        if loja:
            return qs.filter(loja=loja)   # ← adicione aqui
        return qs
    return qs.filter(responsavel=user)
```

Nenhuma view precisa ser alterada.

---

## Regras de Design

1. **`permissions.py`** — Única fonte de verdade sobre "quem pode fazer o quê".
   Nunca coloque `if user.is_superuser` ou `if profile.nivel` nas views.

2. **`services/`** — Única fonte de verdade sobre regras de negócio.
   Serviços validam permissão internamente e lançam exceções tipadas.

3. **Views** — Apenas orquestram: recebem HTTP → chamam service → tratam exceção → respondem.

4. **`filtrar_viagens()`** — Todo `ListView` que exibe viagens deve passar pelo filtro.
   Nunca confie apenas no template para esconder dados.

5. **Testes** — Cada regra em `permissions.py` e `services/` deve ter teste correspondente.

---

## Exceções do Service Layer

| Exceção               | Quando ocorre                                  |
|-----------------------|------------------------------------------------|
| `PermissionDenied`    | Usuário sem permissão para a operação          |
| `ViagemJaFinalizada`  | Tentar finalizar viagem já encerrada           |
| `ValueError`          | Dados inválidos (mochila vazia, inativa, etc.) |

Views capturam essas exceções e exibem `messages.error()`.

---

## Migração dos Templates

Os templates ainda usam `{{ user_profile.pode_editar }}`.
O `_LegacyProfileShim` mantém compatibilidade temporária.

Para migrar gradualmente, substitua nos templates:

```html
<!-- Antes -->
{% if user_profile.pode_editar %}

<!-- Depois -->
{% if user_perms.pode_editar %}
```

Remova `_LegacyProfileShim` quando todos os templates forem migrados.
